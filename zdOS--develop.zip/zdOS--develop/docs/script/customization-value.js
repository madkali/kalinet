// This file is for you to customize.
// It defines some of the key values.

// the default language for the site; 
const default_language = 'zh-CN';

// define is the document supports version
const versionIsSupported = false;

//github url for enabling Edit on GitHub
const github_url = 'https://github.com/cryptape/Neuron-Android/blob/master/docs/';
