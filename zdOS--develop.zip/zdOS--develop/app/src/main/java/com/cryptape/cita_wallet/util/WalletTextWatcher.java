package com.cryptape.cita_wallet.util;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * Created by BaojunCZ on 2018/11/28.
 */
public class WalletTextWatcher implements TextWatcher {
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
