package com.cryptape.cita_wallet.event;

public class TokenRefreshEvent {
}
