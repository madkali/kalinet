package com.cryptape.cita_wallet.event

/**
 * Created by BaojunCZ on 2018/11/20.
 */
class AddTokenRefreshEvent