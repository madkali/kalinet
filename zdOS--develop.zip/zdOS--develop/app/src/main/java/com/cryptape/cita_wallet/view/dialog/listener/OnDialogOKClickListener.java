package com.cryptape.cita_wallet.view.dialog.listener;

import android.app.Dialog;

/**
 * Created by BaojunCZ on 2018/8/28.
 */
public interface OnDialogOKClickListener {

    void onClick(Dialog dialog);

}
