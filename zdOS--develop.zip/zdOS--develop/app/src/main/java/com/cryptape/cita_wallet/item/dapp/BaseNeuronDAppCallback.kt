package com.cryptape.cita_wallet.item.dapp

/**
 * Created by BaojunCZ on 2018/11/5.
 */
open class BaseCytonDAppCallback constructor(var status: Int, var errorCode: Int, var errorMsg: String)
