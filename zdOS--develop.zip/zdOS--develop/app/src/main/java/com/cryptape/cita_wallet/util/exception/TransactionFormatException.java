package com.cryptape.cita_wallet.util.exception;

/**
 * Created by duanyytop on 2018/11/29.
 */
public class TransactionFormatException extends Exception {
    public TransactionFormatException(String message) {
        super(message);
    }
}
