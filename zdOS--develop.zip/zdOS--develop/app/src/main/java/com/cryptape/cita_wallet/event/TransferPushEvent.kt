package com.cryptape.cita_wallet.event

/**
 * Created by BaojunCZ on 2018/12/10.
 */
class TransferPushEvent