package com.cryptape.cita_wallet.view.webview;

import com.cryptape.cita_wallet.view.webview.item.Transaction;

public interface OnSignTransactionListener {
    void onSignTransaction(Transaction transaction);
}
