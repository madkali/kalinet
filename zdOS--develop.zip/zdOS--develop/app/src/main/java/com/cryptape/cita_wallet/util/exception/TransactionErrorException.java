package com.cryptape.cita_wallet.util.exception;

public class TransactionErrorException extends Exception {

    public TransactionErrorException(String message) {
        super(message);
    }

}
