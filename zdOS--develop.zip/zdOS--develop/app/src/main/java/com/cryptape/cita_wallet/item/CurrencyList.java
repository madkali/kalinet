package com.cryptape.cita_wallet.item;

import java.util.ArrayList;

/**
 * Created by BaojunCZ on 2018/8/3.
 */
public class CurrencyList {
    private ArrayList<Currency> currency = new ArrayList<>();

    public ArrayList<Currency> getCurrency() {
        return currency;
    }

    public void setCurrency(ArrayList<Currency> currency) {
        this.currency = currency;
    }
}
