package com.cryptape.cita_wallet.event

/**
 * Created by BaojunCZ on 2018/11/21.
 */
class CurrencyRefreshEvent